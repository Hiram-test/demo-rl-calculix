# 排除内容与限制

## 本包未包含

本轮会话开始时，本地工作区已经轮换为空快照。以下内容此前没有作为独立文件持久化，因此无法在本次打包时恢复其原始字节：

- 正式运行目录中由完整性清单封存的 571 个原始文件；
- CalculiX 的 `.frd`、`.dat`、`.sta`、`.cvg`、`.inp` 和求解日志；
- Gmsh 的 `.msh`、几何输入和逐轮网格生成收据；
- 经典 AFEM、SPR-ZZ、三方法绘图及 PDF 生成器的 Python 源文件；
- 原仓库分支的完整 Git 检出与历史。

独立分支新增实现的源码仍包含在 `01_implementation_prototype/one_shot_region_pso_impl.zip` 中；缺失的是后来本地 T 梁实验的经典 AFEM/SPR-ZZ/绘图生成源码。相关对象的原路径、关键 SHA-256 和正式运行身份保留在 `04_classic_spr_zz_final/audits/tbeam_afem_delivery_manifest.json`、`04_classic_spr_zz_final/audits/summary.json` 与 `04_classic_spr_zz_final/data/classic_afem_trajectory.csv` 中，但缺失对象的原始字节不在本包内。因此本包是“全部可恢复发布工件”，不是“原始求解证据与源码全量复现包”。

## 主动排除

以下内容即使存在也不应纳入正式包：

- 并发写入污染的终端求解目录；
- 被隔离的失败/中止/旧版本运行；
- CalculiX ZZS 出现病态恢复值的作废轨迹；
- 已被 corrected 版本替代、曾造成“T 梁看起来碎裂”的旧网格图；
- 下载过程产生的重复临时文件；
- 与本次 T 梁实验无关的历史项目工件。

## 数值与方法限制

- 自适应网格由 Gmsh 非嵌套重生成，DOF 与指标不保证逐轮单调。
- 静力能量型 ZZ 标记不保证单一端部位移 QoI 相对有限 H32 参考单调。
- D-NLG 的 operational ZZ 使用参考构形直边体积、线弹性柔度和 CalculiX Cauchy 应力差，仅作为标记代理。
- S-LIN 和 D-NLG 都因十轮安全上限而停止，未达到 4 倍 DOF；没有插值或伪造 4 倍点。
- 960 MPa 是外加名义资格限值，不是 deck 中声明的材料屈服强度。
